# LeetPush

Chrome extension (Manifest V3) that pushes your accepted solutions to a GitHub repo.
Supports LeetCode, Codeforces, CodeChef, HackerRank and GeeksforGeeks.

## Setup

1. Create an empty GitHub repo (e.g. `dsa-solutions`).
2. Create a fine-grained personal access token: GitHub > Settings > Developer settings > Personal access tokens > Fine-grained. Limit it to that one repo with **Contents: Read and write**.
3. Open `chrome://extensions`, turn on **Developer mode**, click **Load unpacked**, and pick this folder.
4. Click the LeetPush icon, enter the token and `username/repo`, press **Save**, then **Test repo**.
5. Submit a solution on any supported site. When it is accepted, the icon badge shows OK and the files appear in your repo.

## Output layout

```
<folder>/LeetCode/0001-two-sum/two-sum.py
<folder>/Codeforces/4A-watermelon/watermelon.cpp
<folder>/HackerRank/solve-me-first/solve-me-first.py
<folder>/GeeksforGeeks/<problem-slug>/<problem-slug>.java
<folder>/CodeChef/<PROBLEMCODE>/<problemcode>.cpp
```

Each folder also gets a small `README.md` with the problem link, language and stats.

## How each platform is detected

| Platform | Method | Confidence |
|---|---|---|
| LeetCode | Watches the submission result poll, then reads details via GraphQL | Tested pattern, same as most sync tools |
| Codeforces | Watches your own status page (`/my`) for a row turning Accepted, then reads the source from the submission page | DOM selectors, may need tweaks |
| HackerRank | Watches `/rest/contests/.../submissions/<id>` for status "Accepted" | Endpoint from memory, verify |
| GeeksforGeeks | Remembers the code sent to their API, then treats "Problem Solved Successfully" as accepted | Heuristic, verify |
| CodeChef | Remembers code sent to their API, then looks for an accepted result code | Heuristic, least certain |

Codeforces only pushes submissions that turn Accepted while the status page is open (so
old accepted rows are never re-pushed). After submitting, stay on the `/my` page until
the verdict appears.

## If a platform doesn't push

Open the site, press F12, go to Console, and filter for `[LeetPush]`. The HackerRank and
CodeChef scripts log the verdicts they see, which shows what to adjust in the matching
`inject-<site>.js` file. Errors also show in the popup under "Last".

## Notes

- Sites change their internal APIs now and then.
- The token is stored in `chrome.storage.sync`. Use a repo-scoped token only.
