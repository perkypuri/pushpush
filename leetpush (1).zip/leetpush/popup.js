const fields = ["token", "repo", "branch", "folder"];
const $ = (id) => document.getElementById(id);
const boxes = [...document.querySelectorAll("input[data-p]")];

chrome.storage.sync.get([...fields, "enabled"]).then((v) => {
  fields.forEach((f) => ($(f).value = v[f] || ""));
  boxes.forEach((b) => (b.checked = !v.enabled || v.enabled[b.dataset.p] !== false));
});
chrome.storage.local.get("last").then(({ last }) => {
  $("last").textContent = last ? `Last: ${last}` : "";
});

function say(text) {
  $("status").textContent = text;
}

async function save() {
  const v = {};
  fields.forEach((f) => (v[f] = $(f).value.trim()));
  v.enabled = Object.fromEntries(boxes.map((b) => [b.dataset.p, b.checked]));
  await chrome.storage.sync.set(v);
  return v;
}

$("save").addEventListener("click", async () => {
  await save();
  say("Saved");
});

$("test").addEventListener("click", async () => {
  const v = await save();
  if (!v.token || !v.repo) return say("Enter a token and repo first");
  say("Checking...");
  try {
    const res = await fetch(`https://api.github.com/repos/${v.repo}`, {
      headers: { Authorization: `Bearer ${v.token}`, Accept: "application/vnd.github+json" },
    });
    if (!res.ok) return say(`GitHub says ${res.status}: check the token and repo name`);
    const j = await res.json();
    say(j.permissions?.push ? "Repo found, push access OK" : "Repo found, but the token has no write access");
  } catch (e) {
    say(`Failed: ${e.message}`);
  }
});
