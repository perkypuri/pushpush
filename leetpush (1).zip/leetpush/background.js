const PLATFORM_NAME = {
  leetcode: "LeetCode",
  codeforces: "Codeforces",
  codechef: "CodeChef",
  hackerrank: "HackerRank",
  gfg: "GeeksforGeeks",
};

// First matching rule wins (order matters: c++ before c, javascript before java...).
const EXT_RULES = [
  [/c\+\+|cpp/, "cpp"],
  [/c#|csharp/, "cs"],
  [/typescript/, "ts"],
  [/javascript|node/, "js"],
  [/python|pypy/, "py"],
  [/kotlin/, "kt"],
  [/java/, "java"],
  [/golang|(^|[^a-z])go([^a-z]|$)/, "go"],
  [/rust/, "rs"],
  [/swift/, "swift"],
  [/ruby/, "rb"],
  [/scala/, "scala"],
  [/php/, "php"],
  [/dart/, "dart"],
  [/racket/, "rkt"],
  [/erlang/, "erl"],
  [/elixir/, "ex"],
  [/bash|shell/, "sh"],
  [/sql/, "sql"],
  [/(^|[^a-z+#])c(\d+)?([^a-z+#]|$)/, "c"],
];

function extFor(lang) {
  const l = String(lang || "").toLowerCase();
  for (const [re, ext] of EXT_RULES) if (re.test(l)) return ext;
  return "txt";
}

const b64 = (str) => btoa(unescape(encodeURIComponent(str)));

function badge(text, color) {
  chrome.action.setBadgeText({ text });
  chrome.action.setBadgeBackgroundColor({ color });
  setTimeout(() => chrome.action.setBadgeText({ text: "" }), 5000);
}

async function gh(path, token, options = {}) {
  return fetch(`https://api.github.com${path}`, {
    ...options,
    headers: {
      Accept: "application/vnd.github+json",
      Authorization: `Bearer ${token}`,
      "X-GitHub-Api-Version": "2022-11-28",
      ...(options.headers || {}),
    },
  });
}

// Create or update a file; skips the commit if content is unchanged.
async function putFile({ token, repo, branch, path, content, message }) {
  const url = `/repos/${repo}/contents/${path.split("/").map(encodeURIComponent).join("/")}`;
  let sha;
  const existing = await gh(`${url}?ref=${encodeURIComponent(branch)}`, token);
  if (existing.ok) {
    const j = await existing.json();
    if (j.content && j.content.replace(/\n/g, "") === b64(content)) return "unchanged";
    sha = j.sha;
  } else if (existing.status !== 404) {
    throw new Error(`GitHub ${existing.status}: ${(await existing.text()).slice(0, 200)}`);
  }
  const res = await gh(url, token, {
    method: "PUT",
    body: JSON.stringify({ message, content: b64(content), branch, ...(sha ? { sha } : {}) }),
  });
  if (!res.ok) throw new Error(`GitHub ${res.status}: ${(await res.text()).slice(0, 200)}`);
  return sha ? "updated" : "created";
}

async function pushSolution(d) {
  const cfg = await chrome.storage.sync.get(["token", "repo", "branch", "folder", "enabled"]);
  if (cfg.enabled && cfg.enabled[d.platform] === false) return "disabled";
  if (!cfg.token || !cfg.repo) {
    throw new Error("Set your GitHub token and repo in the LeetPush popup first");
  }

  const branch = cfg.branch || "main";
  const platformName = PLATFORM_NAME[d.platform] || d.platform;
  const dir = [(cfg.folder || "").replace(/^\/|\/$/g, ""), platformName, d.key]
    .filter(Boolean)
    .join("/");
  const label = `${d.qid ? d.qid + ". " : ""}${d.title}`;

  const result = await putFile({
    token: cfg.token,
    repo: cfg.repo,
    branch,
    path: `${dir}/${d.slug}.${extFor(d.lang)}`,
    content: d.code,
    message: `Add ${platformName}: ${label} (${d.lang})`,
  });

  if (result !== "unchanged") {
    const stats = Object.entries(d.stats || {})
      .filter(([, v]) => v)
      .map(([k, v]) => `- ${k}: ${v}`)
      .join("\n");
    const readme =
      `# ${label}\n\n- Platform: ${platformName}\n` +
      (d.difficulty ? `- Difficulty: ${d.difficulty}\n` : "") +
      `- Language: ${d.lang}\n` +
      (stats ? stats + "\n" : "") +
      `- Problem: ${d.url}\n`;
    await putFile({
      token: cfg.token,
      repo: cfg.repo,
      branch,
      path: `${dir}/README.md`,
      content: readme,
      message: `Add README for ${platformName}: ${label}`,
    });
  }
  return result;
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "PUSH") {
    const d = msg.data;
    pushSolution(d)
      .then(async (result) => {
        if (result === "disabled") return;
        badge("OK", "#2e7d32");
        await chrome.storage.local.set({
          last: `${new Date().toLocaleString()}: ${PLATFORM_NAME[d.platform]} ${d.qid ? d.qid + ". " : ""}${d.title} (${result})`,
        });
      })
      .catch(async (err) => {
        badge("ERR", "#c62828");
        await chrome.storage.local.set({ last: `Error: ${err.message}` });
      });
  } else if (msg.type === "ERROR") {
    badge("ERR", "#c62828");
    chrome.storage.local.set({ last: `Error: ${msg.message}` });
  }
});
